module.exports = {
  plugins: [
    'gatsby-plugin-postcss',
    'gatsby-plugin-typescript',
  ],
}
