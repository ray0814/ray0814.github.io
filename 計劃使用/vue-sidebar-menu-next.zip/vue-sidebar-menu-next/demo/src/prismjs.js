import Prism from 'prismjs'
import 'prismjs/components/prism-scss'
import './prism-vsc-dark-plus.css'
import 'prismjs/plugins/normalize-whitespace/prism-normalize-whitespace.min.js'

export default Prism
