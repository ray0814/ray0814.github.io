<?php

declare(strict_types = 1);

return [
    'move_user_menu' => true,
    'move_theme_switcher' => true,
    'move_notification_center' => false,
    'section_title' => true,
    'collapse_on_select' => false,
    'collapse_on_refresh' => false,
];
