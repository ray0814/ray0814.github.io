<script>
    export default {
        name: 'Noop',
    }
</script>
