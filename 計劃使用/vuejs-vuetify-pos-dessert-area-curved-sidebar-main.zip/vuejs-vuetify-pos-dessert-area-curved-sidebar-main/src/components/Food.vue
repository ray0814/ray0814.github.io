<template>
  <v-row>
        <v-col cols="12" sm="4">
          <v-card
            color="#E8EDE2"
            class="d-flex align-center rounded-lg mx-2"
            dark
            height="100"
            flat
          >
            <v-row>
              <v-col cols="12" sm="2">
                <v-img src="k.png" max-height="100%" max-width="100%"></v-img>
              </v-col>
              <v-col cols="12" sm="4">
                <h4 class="black--text">Kiwi fruit</h4>
                <br />
                <h6 class="black--text mt-n4">Vitamine A Vitamine C</h6>
              </v-col>
              <v-col cols="12" sm="3">
                <h4 class="black--text mt-2">Kk 61</h4>
              </v-col>
            </v-row>
          </v-card>
        </v-col>
        <v-col cols="12" sm="4">
          <v-card
            color="#F6ECDD"
            class="d-flex align-center rounded-lg mx-2"
            dark
            height="100"
            flat
          >
            <v-row>
              <v-col cols="12" sm="2">
                <v-img
                  class="mt-4 ml-1"
                  src="o.png"
                  max-height="120%"
                  max-width="120%"
                ></v-img>
              </v-col>
              <v-col cols="12" sm="7">
                <h4 class="black--text">Orange</h4>
                <br />
                <h6 class="black--text mt-n4">Vitamine A Vitamine C</h6>
              </v-col>
              <v-col cols="12" sm="3">
                <h4 class="black--text mt-2">Kk 47</h4>
              </v-col>
            </v-row>
          </v-card>
        </v-col>
        <v-col cols="12" sm="4">
          <v-card
            color="#F4F1E6"
            class="d-flex align-center rounded-lg mx-2"
            dark
            height="100"
            flat
          >
            <v-row>
              <v-col cols="12" sm="2">
                <v-img
                  class=" "
                  src="c.png"
                  max-height="100%"
                  max-width="100%"
                ></v-img>
              </v-col>
              <v-col cols="12" sm="4">
                <h4 class="black--text mt-2">Banane</h4>
                <br />
                <h6 class="black--text mt-n4">Vitamine A Vitamine C</h6>
              </v-col>
              <v-col cols="12" sm="4">
                <h4 class="black--text mt-4 ml-n8">Kk 30</h4>
              </v-col>
            </v-row>
          </v-card>
        </v-col>
      </v-row>
      
</template>

<script>
export default {

}
</script>

<style>

</style>