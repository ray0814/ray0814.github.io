<template>
   <v-toolbar flat color="transparent" class="mt-n4">
        <v-toolbar-title class="ml-4">
          <strong>Dessert</strong><span class="grey--text ml-2">Area</span>
        </v-toolbar-title>

        <v-spacer></v-spacer>
        <v-icon color="grey" class="mr-2">fas fa-search</v-icon>
        <v-badge color="#41AB55" overlap content="2" class="mr-3 mt-1">
          <v-icon color="grey" class="">far fa-heart</v-icon>
        </v-badge>
        <v-badge color="#41AB55" overlap content="3" class="mr-2 mt-1">
          <v-icon color="grey">fas fa-shopping-cart</v-icon>
        </v-badge>
      </v-toolbar>
</template>

<script>
export default {

}
</script>

<style>

</style>