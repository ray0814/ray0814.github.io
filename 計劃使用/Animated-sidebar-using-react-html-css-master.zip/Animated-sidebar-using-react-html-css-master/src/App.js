import Menu from "./Component/Menu";

export default function App() {
  return (
    <div className="App">
      <Menu />
    </div>
  );
}
