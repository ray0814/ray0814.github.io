const menuBtn = document.querySelector(".menu-btn");

menuBtn.addEventListener("click", () => {
  document.body.classList.toggle("open");
});
