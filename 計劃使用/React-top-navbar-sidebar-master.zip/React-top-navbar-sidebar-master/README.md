This project is a modren way of making user interface for the web. As in the past we mostly use drop down menus in the website to make user interfaces but after the arrival of frontend libraries the thing changes. Now the sidebar menu is the fastest way of making user interfaces for the website. It has many advantages over the old drop down based user interface. 

#how to use?

Clone the repository 
run npm install
run npm start


#Note: Looking forward to develop a professional website like this. Feel free to contact at contact@musk-technology.com
