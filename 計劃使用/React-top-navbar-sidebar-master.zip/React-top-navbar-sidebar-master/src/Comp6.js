function Comp6() {
    return ( 
        <p>comp6</p>
     );
}

export default Comp6;