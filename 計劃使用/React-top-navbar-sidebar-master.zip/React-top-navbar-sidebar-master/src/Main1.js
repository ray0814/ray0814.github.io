function Main1() {
    return (
        <p>Main1</p>
      );
}

export default Main1;