function Comp12() {
    return ( 

        <p>comp12</p>
     );
}

export default Comp12;