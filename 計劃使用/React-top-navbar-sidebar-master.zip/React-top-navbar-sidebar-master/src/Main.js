function Main() {
    return ( 

        <p>Main</p>
     );
}

export default Main;