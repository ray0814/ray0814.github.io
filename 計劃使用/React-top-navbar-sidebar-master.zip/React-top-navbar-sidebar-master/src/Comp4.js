function Comp4() {
    return ( 

        <p>Comp4</p>
     );
}

export default Comp4;