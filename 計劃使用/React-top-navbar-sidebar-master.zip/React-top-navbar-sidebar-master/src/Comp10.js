function Comp10() {
    return ( 
        <p>comp10</p>
     );
}

export default Comp10;