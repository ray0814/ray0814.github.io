function Comp9() {
    return ( 
        <p>comp9</p>
     );
}

export default Comp9;