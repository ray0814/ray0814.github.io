function Comp3() {
    return ( 
        <p>comp3</p>
     );
}

export default Comp3;