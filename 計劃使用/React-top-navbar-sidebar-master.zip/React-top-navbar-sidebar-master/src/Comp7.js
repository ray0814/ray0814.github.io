function Comp7() {
    return (  

        <p>comp7</p>
    );
}

export default Comp7;