function Comp1() {
    return ( 


        <p>Comp1</p>
     );
}

export default Comp1;