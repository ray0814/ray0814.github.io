function Comp8() {
    return ( 
        <p>comp8</p>
     );
}

export default Comp8;