function Comp2() {
    return ( 


        <p>comp2</p>
     );
}

export default Comp2;