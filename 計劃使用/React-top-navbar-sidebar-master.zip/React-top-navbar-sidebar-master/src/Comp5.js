function Comp5() {
    return (
        <p>comp5</p>
     );
}

export default Comp5;