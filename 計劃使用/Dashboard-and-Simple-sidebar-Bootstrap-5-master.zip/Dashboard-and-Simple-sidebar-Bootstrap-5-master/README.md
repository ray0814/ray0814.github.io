# Simple sidebar bootstrap 5
Simple sidebar with navbar in pure Bootstrap 5 and two examples of different sidebar and navbar in different positions 100% responsive and include option to changue color Theme between light or dark.

These two demos include difrent ways to visualize a sidebar and navbar in a simple way.

## Option 1
[Preview](https://alfonsolpzny.github.io/sidebar1/)

<img src="https://github.com/alfonsolpzny/Simple-sidebar-Bootstrap-5/assets/84392982/9098c872-d6b9-43e8-a24e-7b9db0949f92" alt="imagen_2024-02-07_123259413" style="width:600px;"/>


## Option 2
[Preview](https://alfonsolpzny.github.io/sidebar2/)

<img src="https://github.com/alfonsolpzny/Simple-sidebar-Bootstrap-5/assets/84392982/528ff45b-fb48-4bf6-99a8-bd404895b97c" alt="imagen_2024-02-07_123146056" style="width:600px;"/>



Feel free of use.

