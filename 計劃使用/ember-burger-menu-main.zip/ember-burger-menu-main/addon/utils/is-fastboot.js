export default function isFastboot() {
  return !self.document;
}
