import Animation from 'ember-burger-menu/animations/base';

export default Animation.extend({
  animation: 'slide',
});
