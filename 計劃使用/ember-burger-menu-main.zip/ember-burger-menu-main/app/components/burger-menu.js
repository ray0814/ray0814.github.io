export { default } from 'ember-burger-menu/components/burger-menu';
