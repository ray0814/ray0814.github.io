export { default } from 'ember-burger-menu/components/bm-menu';
