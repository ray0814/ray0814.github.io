package com.d.ui.layout.banner;

/**
 * BannerBean
 * Created by D on 2019/12/6.
 */
public class BannerBean {
    public String url;

    public BannerBean(String url) {
        this.url = url;
    }
}
