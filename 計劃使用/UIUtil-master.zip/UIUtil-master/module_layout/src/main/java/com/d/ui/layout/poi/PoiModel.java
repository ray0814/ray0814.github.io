package com.d.ui.layout.poi;

/**
 * Created by D on 2017/11/30.
 */
public class PoiModel {
    public String label_title;
    public String address;

    public PoiModel(String label_title, String address) {
        this.label_title = label_title;
        this.address = address;
    }
}
