package com.d.lib.ui.view.sort;

/**
 * SortBean
 * Created by D on 2017/6/7.
 */
public class SortBean {
    public String content;
    public String letter;
    public String pinyin;
    public boolean isLetter;

    public SortBean(String content) {
        this.content = content;
    }
}
