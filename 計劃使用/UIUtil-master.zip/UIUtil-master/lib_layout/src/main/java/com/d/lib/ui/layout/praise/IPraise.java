package com.d.lib.ui.layout.praise;

/**
 * Created by D on 2016/11/10.
 */
public interface IPraise {
    void onAnimationEnd();
}