package com.d.lib.ui.layout.convenientbanner.listener;

/**
 * Created by Sai on 15/11/13.
 */
public interface OnItemClickListener {
    public void onItemClick(int position);
}
