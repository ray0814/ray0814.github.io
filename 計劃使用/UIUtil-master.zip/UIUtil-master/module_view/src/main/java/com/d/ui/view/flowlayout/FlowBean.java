package com.d.ui.view.flowlayout;

class FlowBean {
    public int index;
    public String tag;

    public FlowBean(String tag) {
        this.tag = tag;
    }
}
