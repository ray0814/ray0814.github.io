package com.d.ui.view.advertswitcher;

class AdvertSwitcherBean {
    public String no;
    public String content;
    public int imgRes;

    public AdvertSwitcherBean(String no, String content, int imgRes) {
        this.no = no;
        this.content = content;
        this.imgRes = imgRes;
    }
}
