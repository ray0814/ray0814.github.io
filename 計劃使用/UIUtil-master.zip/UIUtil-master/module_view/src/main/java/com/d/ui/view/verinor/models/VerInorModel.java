package com.d.ui.view.verinor.models;

/**
 * Created by D on 2017/1/4.
 */
public class VerInorModel {
    public String content = "";
}
