export const parameters = {
  options: {
    storySort: {
      order: ['Sidebar', 'Menu', 'MenuItem', 'SubMenu', 'Playground'],
    },
  },
};
