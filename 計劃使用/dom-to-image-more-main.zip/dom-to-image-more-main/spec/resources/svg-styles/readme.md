This is a repro for [#90]
