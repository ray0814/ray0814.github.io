# Use case: description, code

[jsfiddle](https://jsfiddle.net/IDisposable/emjL1ow8/)

## Expected behavior

## Actual behavior (stack traces, console logs etc)

## Library version

## Browsers

- [ ] Chrome 49+
- [ ] Firefox 45+
