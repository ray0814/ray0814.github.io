npm run build
git push
git push --tags
npm publish