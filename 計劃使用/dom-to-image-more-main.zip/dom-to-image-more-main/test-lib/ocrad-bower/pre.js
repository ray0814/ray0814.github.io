var OCRAD = (function(){
	