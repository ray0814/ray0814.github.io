export const isWindows = () => process.platform === 'win32'
