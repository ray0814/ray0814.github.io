export const isHiddenFile = (fileName: string): boolean => fileName.substring(0, 1) === '.'
