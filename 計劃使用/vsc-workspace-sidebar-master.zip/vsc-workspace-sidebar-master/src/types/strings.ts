export type StringObject = {
  [key: string]: string
}
