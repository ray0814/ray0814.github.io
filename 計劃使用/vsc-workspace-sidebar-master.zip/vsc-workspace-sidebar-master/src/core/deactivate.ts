export const deactivate = (): void => {}
