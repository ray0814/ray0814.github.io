export const DEFAULT_THEME = 'vs-seti'
export const FILE_ICON = 'file'
export const WORKSPACE_ICON = 'workspace'
