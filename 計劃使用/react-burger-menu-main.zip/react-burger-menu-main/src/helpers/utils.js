export const pxToNum = val => parseInt(val.slice(0, -2), 10);
